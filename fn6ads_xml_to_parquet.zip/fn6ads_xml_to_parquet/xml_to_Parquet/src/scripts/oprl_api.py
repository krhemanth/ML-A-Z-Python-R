# information and trade secrets of  Fannie Mae. Use, disclosure, or reproduction is    
# prohibited without the prior written consent of  Fannie Mae.
# 
# Created on Fri Oct 14 13:44:07 2020
# 
# @author: gaupbn, g9usqv
# 
# API utilities
# =============================================================================

import requests
import os
from logger  import mylogger
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class oprl_api(object):
    url = os.getenv("api_url")
    logger = mylogger.getLogger("oprl_api")

    def post(self, job_name, json_request):
        try:
            resp = requests.post(self.url + os.getenv(job_name), json=json_request, verify=False)
            if resp.status_code != 200:
                # something went wrong.
                raise Exception('ERROR: An error happened during API post - Error code {}'.format(resp.status_code))
            else:
                return resp.json()
        except Exception as e:
            self.logger.info('ERROR: An error happened during API post', e)
            raise e
        
    def put(self, job_name, json_request):
        try:
            resp = requests.put(self.url + os.getenv(job_name), json=json_request, verify=False)
            if resp.status_code != 200:
                # something went wrong.
                raise Exception('ERROR: An error happened during API put - Error code {}'.format(resp.status_code))
            else:
                return resp.status_code
        except Exception as e:
            self.logger.info('ERROR: An error happened during API put', e) 
            raise e  
        
    def get_batchRecordByKey(self, prcs_excn_log_id):
        try:
            resp = requests.get(self.url + os.getenv("get_BatchRecordByKey") + prcs_excn_log_id , verify=False)
            
            if resp.status_code != 200:
                raise Exception('ERROR: An error happened during API call - Error code {}'.format(resp.status_code))
                # resp.raise_for_status()
 
            return resp.json()
            
        except Exception as e:
            self.logger.info(e)
        except requests.exceptions.HTTPError as errh:
            self.logger.info ("Http Error: {}".format(errh.response.text))
        except requests.exceptions.ConnectionError as errc:
            self.logger.info ("Error Connecting: {}".format(errc.response.text))
        except requests.exceptions.Timeout as errt:
            self.logger.info ("Timeout Error: {}".format(errt.response.text))
        except requests.exceptions.RequestException as err:
            self.logger.info ("OOps: Something Else happened : {}".format(err.response.text))
        
    def get_jobRecordByKey(self, prcs_excn_log_id, prcs_job_excn_log_id):
        try:
            
            resp = requests.get(self.url + os.getenv("get_JobRecordByKey") + prcs_job_excn_log_id + "/" + prcs_excn_log_id , verify=False)
            if resp.status_code != 200:
                # something went wrong.
                raise Exception('ERROR: An error happened during API get jobRecordByKey - Error code {}'.format(resp.status_code))
            else:
                return resp.json()
        except Exception as e:
            self.logger.info('ERROR: An error happened during API get jobRecordByKey', e) 
            raise e
        
    def get_allJobRecord(self):
        try:
            
            resp = requests.get(self.url + os.getenv("get_AllJobRecord"), verify=False)
            if resp.status_code != 200:
                # something went wrong.
                raise Exception('ERROR: An error happened during API get AllJobRecord - Error code {}'.format(resp.status_code))
            else:
                return resp.json()
        except Exception as e:
            self.logger.info('ERROR: An error happened during API get AllJobRecord', e) 
            raise e  


api = oprl_api()

