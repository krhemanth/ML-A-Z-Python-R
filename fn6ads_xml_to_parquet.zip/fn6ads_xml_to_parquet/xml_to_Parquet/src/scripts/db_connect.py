import psycopg2
from logger  import mylogger
from pam_utils import pam


class db_connect(object):
    
    logger = mylogger.getLogger("db_connect")

    def connect(self, section):
        
        """ Connect to the PostgreSQL, redshift database server """
        conn = None
        try:
            # read connection parameters
            params = pam.get_pam_details(section)
    
            self.logger.info('Connecting to the %s database...' % (section))
            conn = psycopg2.connect(**params)
            if section == 'postgress':
                self.logger.info('Successfully connected to %s database: %s  schema: %s' % (section, params.get('database'), params.get('options').split('=')[1]))
            else:
                self.logger.info('Successfully connected to %s database: %s' % (section, params.get('database')))
                
            return conn
        
        except (Exception, psycopg2.DatabaseError) as error:
            self.logger.debug(error)
            raise error
        
    def execute_query(self, sql: list, table, section):
        try: 
            '''Establish a RDS connection '''
            conn = self.connect(section)
            cur = conn.cursor()
                
            cur.execute("".join(sql))
            self.logger.info('Executing the query on %s table.' % table)
            recs = [r for r in cur.fetchall()]
            cur.close()
            return recs
        
        except Exception as error:
            print(error)
            raise error    
        finally:
            if conn is not None:
                conn.close()
                self.logger.info('%s connection closed.' % section)
    
    def execute_copy(self, sql: list, table, section):
        try: 
            '''Establish a RDS connection '''
            conn = self.connect(section)
            # create a cursor
            cur = conn.cursor()
            
            self.logger.info('Copying table: %s' % table)
            cur.execute("".join(sql))
            conn.commit()
            
            self.logger.info('Successfully copied: %s' % table)
            cur.close()
        
        except Exception as error:
            self.logger.info('%s copy error: %s' % (section.capitalize(), error))
            raise error    
        finally:
            if conn is not None:
                conn.close()
                self.logger.info('%s connection closed.' % section)

        
db = db_connect()
