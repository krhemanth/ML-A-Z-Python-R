import boto3
import shlex
import os
import datetime
from os.path import basename
import json
import shutil
from os.path import join
import argparse
from logger import mylogger
from oprl_api import api
from db_connect import db
from parquet_conversion import p_conversion
import subprocess
from pyspark import SparkContext, SparkConf
import botocore


def download_xlm_files_to_emr():

    try:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Started the XML Download Process **')
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

        # Setting the variables
        prcs_job_excn_stat_typ = 'Running'

        input_dir = os.getenv("input_dir")
        input_dir = join(input_dir, str(prcs_excn_log_id))

        '''Additional check to see if the prcs_exec_log table is in Running status  '''
        batch_rec = api.get_batchRecordByKey(prcs_excn_log_id)

        if not batch_rec:
            raise Exception("No record found for Process - {} in prcs_excn_log table".format(prcs_excn_log_id))

        if batch_rec['prcs_excn_stat_typ'].strip() != 'Initiated':
            logger.info("Check the process - {} is not in 'Initiated' state... Failed".format(prcs_excn_log_id))
            logger.info("Process - {} is in '{}' state".format(prcs_excn_log_id, batch_rec['prcs_excn_stat_typ']))
            raise Exception("Process - {} is in '{}' state... Failed".format(prcs_excn_log_id, batch_rec['prcs_excn_stat_typ']))
        logger.info("Check the process - {} is in 'Initiated' state... Done".format(prcs_excn_log_id))

        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, prcs_job_excn_stat_typ)

        column1 = 'src_pyld_s3_loc'
        column2 = 'rec_last_updd_dttm'
        column3 = 'data_load_status'
        table = 'msg_meta_data'

        # create the sql statement
        '''select src_msg_s3_loc from msg_meta_data where rec_last_updd_dttm >= to_date (<< >>,'YYYY-MM-DD HH24:MI:SS') and rec_last_updd_dttm < to_date (<< >>,'YYYY-MM-DD HH24:MI:SS')and data_load_status = 'C' '''

        sql = list()
        sql.append("SELECT %s FROM %s " % (column1, table))
        sql.append("WHERE %s >= to_timestamp('%s' , 'YYYY-MM-DD HH24:MI:SS') AND  %s < to_timestamp('%s' , 'YYYY-MM-DD HH24:MI:SS') AND %s = 'T'" % (column2, strt_date, column2, end_date, column3))
        sql.append(";")

        s3_list = [e for e, in db.execute_query(sql, table, 'postgresql')]

        if not s3_list:
            raise Exception(logger.info("No messages to download for the given date range. Start Date - {}  End Date - {}".format(strt_date, end_date)))

        s3 = boto3.resource('s3')
        bucket_name = os.getenv("bucket_name")

        '''Create dir if doesn't exist, else delete the dir and recreates it '''
        if os.path.exists(input_dir):
            shutil.rmtree(input_dir)
        os.makedirs(input_dir)

        logger.info("Downloading file to EMR from S3... Started")
        for s3_path in s3_list:
            file_name = os.path.basename(s3_path).strip()
            input_dir_final = join(input_dir, file_name)
            logger.info("Downloading file: {}".format(file_name))
            try:
                s3.meta.client.download_file(bucket_name, s3_path, input_dir_final)
            except botocore.exceptions.ClientError as e:
                if e.response['Error']['Code'] == "404":
                    logger.info("File not found in s3: {}".format(file_name))
                else:
                    logger.info("The Error code to be chekced is : {}".format(str(e)))

        logger.info("Successfully downloaded all files to : " + input_dir)
        status = 'Completed'
        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, status)

    except Exception as error:
        status = 'Failed'
        logger.info(error)
        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, status)
    finally:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info("** XML Download Process {} **".format(status.upper()))
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')


def xml_parsing_using_draper():
    try:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Started the Draper Process **')
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        
        script_dir = os.getenv('script_dir')
        script_name = os.getenv('script_name')
        prcs_job_excn_stat_typ = "Running"

        input_dir = os.getenv("input_dir")
        output_dir = os.getenv("output_dir")

        output_dir = join(output_dir, str(prcs_excn_log_id))
        input_dir = join(input_dir, str(prcs_excn_log_id))

        '''Create dir if doesn't exist, else delete the dir and recreates it '''
        if os.path.exists(output_dir):
            shutil.rmtree(output_dir)
        os.makedirs(output_dir)

        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, prcs_job_excn_stat_typ)

        cmd = 'sh {0} {1} {2} {3}'.format(script_name, input_dir, output_dir, prcs_excn_log_id)
        args = shlex.split(cmd)

        p = subprocess.Popen(args, stderr=subprocess.PIPE, cwd=script_dir)
        p.wait()

        if p.returncode != 0 :
            raise Exception('Draper process failded: Error {0} - {1}'. format(p.returncode, p.stderr))
        else:
            status = "Completed"
            update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, status)

    except Exception as error:
        logger.info(error)
        status = "Failed"
        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, status)
        
    finally:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Draper Process {} **'.format(status.upper()))
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')


def parquet_conversion():
    try:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Started the Parquet Conversion Process **')
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

        output_dir = os.getenv("hdfs_output_dir")
        p_status = "Not Set"
        # res = p_conversion.convert('/mnt/xml_to_Parquet_Output/20201112154845734', '20201112154845734', '20201112154846220')
        status = p_conversion.convert(output_dir, prcs_excn_log_id)
        logger.info("Status of the parquet Conversion return")
        logger.info(status)
        # if p_conversion.convert(output_dir, prcs_excn_log_id):
        if status == True:
            p_status = 'Completed'
            update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, p_status)
        else:
            p_status = 'Failed'
            update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, p_status)

    except Exception as error:
        p_status = "Failed"
        update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, p_status)
        logger.info(error)
    finally:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Parquet Conversion Process {} **'.format(p_status.upper()))
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')


def update_prcs_job_excn_log_status(prcs_excn_log_id, prcs_job_excn_log_id, prcs_job_excn_stat_typ):
    try:
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')
        '''update prcs_job_excn_log table status'''
        json_request = '{{"prcs_excn_log_id": "{0}", "prcs_job_excn_log_id": "{1}", "prcs_job_excn_stat_typ": "{2}", "rec_last_updd_dttm": "{3}"}}'.format(prcs_excn_log_id, prcs_job_excn_log_id, prcs_job_excn_stat_typ, now)
        json_request = json.loads(json_request)
        api.put("prcs_job_excn_log_put", json_request)
        logger.info('Updated the prcs_job_excn_log status to {}... Done'.format(prcs_job_excn_stat_typ))
    except Exception as error:
        logger.debug(error)
        raise error


def check_prcs_job_excn_status_type():
    try:
        column1 = 'prcs_job_excn_stat_typ'
        column2 = 'prcs_excn_log_id'
        column3 = 'prcs_job_excn_log_id'
        table = 'prcs_job_excn_log'

        '''SELECT prcs_job_excn_stat_typ FROM prcs_job_excn_log WHERE prcs_excn_log_id = << >> AND  prcs_job_excn_log_id = << >>; '''

        sql = list()
        sql.append("SELECT %s FROM %s " % (column1, table))
        sql.append("WHERE %s = '%s' AND  %s = '%s'" % (column2, prcs_excn_log_id, column3, prcs_job_excn_log_id))
        sql.append(";")

        status = db.execute_query(sql, table, 'postgresql')
        # status = reduce(lambda x, y: x + [y], status, [])
        return status[0][0].strip()
    
    except Exception as error:
        logger.debug(error)
        raise error


def arg_parser():
    try:

        '''Argument parser to parse all the input values '''
        ap = argparse.ArgumentParser(description='Processing arguments...')
        ap.add_argument("-i", "--input", required=True, type=str, nargs='+', help='JSON input string for this operation')

        # Grab the Arguments
        args = ap.parse_args()
        inputJson = json.dumps(' '.join(args.input))
        inputJson = json.loads(inputJson)
        return inputJson

    except Exception as error:
        logger.debug(error)
        raise error


def job_status_check(job, force_run_key):
    try:
        
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Checking the {} job status **'.format(job))
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        
        status = check_prcs_job_excn_status_type()
        force_run = (os.getenv(force_run_key).upper() == 'TRUE')
        
        if not status:
            raise Exception(logger.info("Job process - {} NOT found in prcs_job_excn_log table".format(prcs_job_excn_log_id)))

        logger.info("Process job - {} is in '{}' state...".format(prcs_excn_log_id, status.upper()))
        
        if (status.upper() not in ('COMPLETED', 'RUNNING') or force_run):
            return True
        else:
            if status.upper() == 'RUNNING':
                logger.warning("Job '{}' is in '{}' state".format(prcs_job_excn_log_id, status.upper()))
                logger.warning("Exiting the process '{}'...".format(prcs_excn_log_id))
            else :
                logger.info("Job '{}' is in '{}' state".format(prcs_job_excn_log_id, status.upper()))
            return False
        
    except Exception as err:
        logger.debug(err)
        raise err
    finally:
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        logger.info('** Completed the job status check **')
        logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')


if __name__ == "__main__":

    global prcs_excn_log_id, prcs_job_excn_log_id, inputJson, output_dir
    
    script_name = basename(__file__)[:-3]
    logger = mylogger.getLogger(script_name)
    output_dir = ""
    
    conf = SparkConf().setAppName("Parquet_Conversion")
    sc = SparkContext(conf=conf)
    sc.setLogLevel("ERROR")

    inputs = arg_parser()
        
    inputJson = json.loads(inputs)
    strt_date = inputJson.get('start_date')
    end_date = inputJson.get('end_date')

    for record in inputJson['Records']:
        prcs_job_id = record.get('prcs_job_id')  # get the id
        if prcs_job_id == 'LDNG-01':
            prcs_excn_log_id_LDNG_01 = record.get('prcs_excn_log_id')
            prcs_job_excn_log_id_LDNG_01 = record.get('prcs_job_excn_log_id')
        elif prcs_job_id == 'LDNG-02':
            prcs_excn_log_id_LDNG_02 = record.get('prcs_excn_log_id')
            prcs_job_excn_log_id_LDNG_02 = record.get('prcs_job_excn_log_id')
        elif prcs_job_id == 'LDNG-03':
            prcs_excn_log_id_LDNG_03 = record.get('prcs_excn_log_id')
            prcs_job_excn_log_id_LDNG_03 = record.get('prcs_job_excn_log_id')

    '''Argument parser to parse all the input values '''
    logger.info("Parsing the input arguments... Done")

    prcs_excn_log_id = prcs_excn_log_id_LDNG_01
    prcs_job_excn_log_id = prcs_job_excn_log_id_LDNG_01
    
    if job_status_check('LDNG-01', 'force_run_file_download'):
        download_xlm_files_to_emr()
    
    if check_prcs_job_excn_status_type().upper() == "COMPLETED":
        prcs_excn_log_id = prcs_excn_log_id_LDNG_02
        prcs_job_excn_log_id = prcs_job_excn_log_id_LDNG_02
    else:
        exit(1)
        
    if job_status_check('LDNG-02', 'force_run_draper'):
        xml_parsing_using_draper()
        
    if check_prcs_job_excn_status_type().upper() == "COMPLETED":
        prcs_excn_log_id = prcs_excn_log_id_LDNG_03
        prcs_job_excn_log_id = prcs_job_excn_log_id_LDNG_03
    else:
        exit(1)
        
    if job_status_check('LDNG-03', 'force_run_parquet'):
        parquet_conversion()

    if check_prcs_job_excn_status_type().upper() == "COMPLETED":
        exit(0)
    else:
        exit(1)
