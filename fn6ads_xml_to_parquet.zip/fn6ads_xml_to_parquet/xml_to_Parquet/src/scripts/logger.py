
# information and trade secrets of  Fannie Mae. Use, disclosure, or reproduction is    
# prohibited without the prior written consent of  Fannie Mae.
# 
# Created on Fri May 24 13:44:07 2019
# 
# @author: gaupbn, g9usqv
# 

# =============================================================================

# DEBUG: Detailed information, typically of interest only when diagnosing problems. 
# INFO: Confirmation that things are working as expected. 
# WARNING: An indication that something unexpected happened, or indicative of some problem in the near future (e.g. disk space low). The software is still working as expected. 
# ERROR: Due to a more serious problem, the software has not been able to perform some function. 
# CRITICAL: A serious error, indicating that the program itself may be unable to continue running. 

import os
import logging as lg
import logging.config
from os.path import join
from os.path import exists
import yaml
import coloredlogs
from config_loader import config
import re
from pathlib import Path
import shutil


def parse_config(filename):
    
    """ parses the YAML config file and expands any environment variables """
    
    ''' use regular expression pattern to identify the variable in the yaml
        add a resolver using a unique pattern
        create a custom constructor to replace the values in yaml when loading using safe_loader
    '''
    try:
        pattern = re.compile(r'\$\{([^}^{]+)\}')
        yaml_tag = '!pathex'    
        yaml.SafeLoader.add_implicit_resolver(yaml_tag, pattern, first=None)
        yaml.add_implicit_resolver(yaml_tag, pattern)
    
        def pathex_constructor(loader, node):
            '''constructor
               replaces the node value with ${} with environment variable  '''
            value = loader.construct_scalar(node)
            match = pattern.match(value)
            env_var = match.group()[2:-1]
            return str(join(os.getenv(env_var), 'logs', value[match.end():]))
        
        '''add the constructor '''    
        yaml.SafeLoader.add_constructor(yaml_tag, pathex_constructor)
        
        with open(filename) as f:
            return(
                yaml.safe_load(f)
            )
    except Exception as e:
            print (e)


class Logger(object):
    
    def __init__(self):
        global pattern
        # Load the logging config yaml file
        try:
            self.log_config = join(os.getenv('root_dir'), 'src/config', os.getenv('log_config'))
            if exists(self.log_config):
                self.config = parse_config(self.log_config)
        except Exception as e:
            print (e)
            
    # Method to get the logger
    # Parameters: module_name
    # Return: logger
    def getLogger(self, module_name):
        
        try:
            log_dir = join(os.getenv('root_dir'), 'logs')
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
                
            if exists(self.log_config): 
                logging.config.dictConfig(self.config)
                coloredlogs.install()
                logger = logging.getLogger(module_name)
            else:
                logger = lg.basicConfig(level=lg.INFO)
                print('Config file not found. Defaulting to basic logger with log level INFO')
        except Exception as e:
            print(e)
            
        return logger


mylogger = Logger()

