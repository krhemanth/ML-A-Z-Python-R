
# Trying this with the glue ETL for Schema Converssion
# lambda - json file wil have all the s3 location of files to be proessed.
# source will be a json file with all the s3 loation of files.

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
import os
import re
import boto3
import json
from os.path import join
# from collections import OrderedDict
from logger  import mylogger


class parquet_conversion(object):

    logger = mylogger.getLogger("parquet_conversion")
    
    def convert(self, draper_out, prcs_excn_log_id):
        
        try:
            Run_status = 0
            bucket_name = os.getenv("bucket_name")
            glue_DB_cin = os.getenv("glue_DB_cin")
            glue_DB_crs = os.getenv("glue_DB_crs")
            glue_DB_chr = os.getenv("glue_DB_chr")
            user = os.getenv("user")
            loc = os.getenv("loc")
            DLSET = os.getenv("DLSET")
            DealSetId_File_loc = join(os.getenv("root_dir"), "src/data", os.getenv("dataset_file_name"))
            with open(DealSetId_File_loc) as f:
                DealSetId_Dic = json.load(f)            
            Table_List_loc = join(os.getenv("root_dir"), "src/data", os.getenv("data_file_name"))
            with open(Table_List_loc) as t:
                Table_List = json.load(t)
            
            sc = SparkContext.getOrCreate()
            spark = SparkSession(sc)
            
            target_loc = 's3://{}/{}/{}/'.format(bucket_name, loc, DLSET)
            # config_path = '{}/{}/config/config.json'.format(loc, DLSET)
            
            # ##The Config is not being used now
            # s3 = boto3.client('s3')
            # s3_object = s3.get_object(Bucket=bucket_name, Key=config_path)
            # config = json.loads(s3_object['Body'].read().decode('utf-8'))
            
            hadoop = sc._jvm.org.apache.hadoop
            fs = hadoop.fs.FileSystem
            conf = hadoop.conf.Configuration()
            path = hadoop.fs.Path(draper_out)
            for f in fs.get(conf).listStatus(path):
                file_path = str(f.getPath())
                table_name = file_path.split('/')[-1]  # Source_Tbl_home=path.split('/')[-3] if epoc time parition is included
                if table_name in Table_List['tables']:
                    self.logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                    self.logger.info("Processing File: {}".format(file_path))
 
                    glue_table = table_name
                    target_loc_final = target_loc + glue_table
                    
                    # Set the File Properties for Source
                    file_type = "csv"
                    infer_schema = "false"
                    first_row_is_header = "true"
                    delimiter = "~"
                    partition_by = "bch_id"
                    
                    df = spark.read.format(file_type).option("inferSchema", infer_schema).option("header", first_row_is_header).option("sep", delimiter).load(file_path)
                    glue_tbl = None
                    glue_lst_col = None
                    try:
                        glue_client = boto3.client("glue", region_name='us-east-1')

                        if table_name.replace('_STGG', '_FACT') in DealSetId_Dic.keys():
                            self.logger.info("Key found" + str(DealSetId_Dic[table_name.replace('_STGG', '_FACT')].split('/')))
                            dset_layer = DealSetId_Dic[table_name.replace('_STGG', '_FACT')].split('/')[0]
                            Cnfdn_lvl = DealSetId_Dic[table_name.replace('_STGG', '_FACT')].split('/')[1]
                            app_sec_grp = DealSetId_Dic[table_name.replace('_STGG', '_FACT')].split('/')[2]
                            dset_reg_id = DealSetId_Dic[table_name.replace('_STGG', '_FACT')].split('/')[3]
                            target_loc_new = "s3://%s/%s/%s/%s/%s/%s/%s" % (bucket_name, dset_layer, Cnfdn_lvl, app_sec_grp, dset_reg_id, 'src', glue_table.lower())
                            self.logger.info("New Tagret Location" + str(target_loc_new))
                            target_loc_final = target_loc_new
                        else:
                            dset_layer = DealSetId_Dic[table_name].split('/')[0]
                            Cnfdn_lvl = DealSetId_Dic[table_name].split('/')[1]
                            app_sec_grp = DealSetId_Dic[table_name].split('/')[2]
                            dset_reg_id = DealSetId_Dic[table_name].split('/')[3]
                            target_loc_new = "s3://%s/%s/%s/%s/%s/%s/%s" % (bucket_name, dset_layer, Cnfdn_lvl, app_sec_grp, dset_reg_id, 'src', glue_table.lower())
                            self.logger.info("New Tagret Location" + str(target_loc_new))
                            target_loc_final = target_loc_new
                        
                        try:
                            self.logger.info("Searching Glue Catalog {} for table {}".format(glue_DB_cin, glue_table))
                            glue_tbl = glue_client.get_table(DatabaseName=glue_DB_cin, Name=glue_table)
                        except Exception as err:
                            try:
                                self.logger.info("Searching Glue Catalog {} for table {}".format(glue_DB_crs, glue_table))
                                glue_tbl = glue_client.get_table(DatabaseName=glue_DB_crs, Name=glue_table)
                            except Exception as err:
                                try:
                                    self.logger.info("Searching Glue Catalog {} for table {}".format(glue_DB_chr, glue_table))
                                    glue_tbl = glue_client.get_table(DatabaseName=glue_DB_chr, Name=glue_table)
                                except Exception as err:
                                    self.logger.error("Glue Catalog not found the error message is:")
                                    self.logger.error(err) 
                                    Run_status = 1
                        
                        glue_lst_col = glue_tbl['Table']['StorageDescriptor']['Columns']
                    
                        col_names = []
                        for i in range(0, len(glue_lst_col)):
                            col_name = glue_lst_col[i]['Name'].upper()
                            dtype = glue_lst_col[i]['Type'].upper()
                            dl_dtype = self.replace(dtype)
                            col_names.append(col_name)
                            
                            comma_loc = str(dtype).find(',')
                            openbraces_loc = str(dtype).find('(')
                            closebraces_loc = str(dtype).find(')')
                            
                            # self.logger.info("Working with Column {} and datatype {} ".format(col_name, dtype))
                            
                            if comma_loc >= 0:
                                precision = dtype[openbraces_loc + 1:comma_loc]
                                scale = dtype[comma_loc + 1:closebraces_loc]
                            elif openbraces_loc >= 0:
                                precision = str(dtype)[openbraces_loc + 1:closebraces_loc]
                                scale = None
                            else:
                                precision = None
                                scale = None
                            
                            # if col_name in config[table_name]['Default_Column'].keys():
                            #    default_value = config[table_name]['Default_Column'][col_name]
                            #    if default_value == "current_timestamp()":
                            #        df = df.withColumn(col_name, lit(current_timestamp()))
                            #    else:
                            #        df = df.withColumn(col_name, lit(default_value))
                            
                            if 'DIM_ID' in col_name:
                                df = df.withColumn(col_name, lit(999))
        
                            if 'FACT_ID' in col_name:
                                df = df.withColumn(col_name, lit(99999))
            
                            if col_name in df.columns:
                                if str(dl_dtype) == 'TimestampType':
                                    # figure out the formats and then aply the conversion
                                    df = df.withColumn(col_name, when(to_timestamp(df[col_name], 'MM/dd/yyyy HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'MM/dd/yyyy HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'MM-dd-yyyy HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'MM-dd-yyyy HH:mm:ss'))\
											.when(to_timestamp(df[col_name], 'yyyy/MM/dd HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'yyyy/MM/dd HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'yyyy/dd/MM HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'yyyy/dd/MM HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'dd-MM-yyyy HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'dd-MM-yyyy HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'dd/MM/yyyy HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'dd/MM/yyyy HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'yyyy-MM-dd HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'yyyy-MM-dd HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'yyyy-dd-MM HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'yyyy-dd-MM HH:mm:ss'))\
                                            .when(to_timestamp(df[col_name], 'yyyy-MM-dd\'T\'HH:mm:ss').isNotNull(), to_timestamp(df[col_name], 'yyyy-MM-dd\'T\'HH:mm:ss'))\
											.when(to_timestamp(df[col_name], 'yyyy-MM-dd').isNotNull(), to_timestamp(df[col_name], 'yyyy-MM-dd'))\
                                            .otherwise(lit(None).cast(TimestampType())))
                                elif str(dl_dtype) == 'DateType':
                                    df = df.withColumn(col_name, when(to_date(df[col_name], 'MM/dd/yyyy').isNotNull(), to_date(df[col_name], 'MM/dd/yyyy'))\
                                            .when(to_date(df[col_name], 'MM-dd-yyyy').isNotNull(), to_date(df[col_name], 'MM-dd-yyyy'))\
											.when(to_date(df[col_name], 'dd/MM/yyyy').isNotNull(), to_date(df[col_name], 'dd/MM/yyyy'))\
											.when(to_date(df[col_name], 'dd-MM-yyyy').isNotNull(), to_date(df[col_name], 'dd-MM-yyyy'))\
                                            .when(to_date(df[col_name], 'yyyy/MM/dd').isNotNull(), to_date(df[col_name], 'yyyy/MM/dd'))\
                                            .when(to_date(df[col_name], 'yyyy/dd/MM').isNotNull(), to_date(df[col_name], 'yyyy/dd/MM'))\
											.when(to_date(df[col_name], 'yyyy-MM-dd').isNotNull(), to_date(df[col_name], 'yyyy-MM-dd'))\
                                            .when(to_date(df[col_name], 'yyyy-dd-MM').isNotNull(), to_date(df[col_name], 'yyyy-dd-MM'))\
                                            .otherwise(lit(None).cast(DateType())))
                                elif str(dl_dtype) == 'IntegerType':
                                    df = df.withColumn(col_name, df[col_name].cast(IntegerType()))
                                elif str(dl_dtype) == 'LongType':
                                    df = df.withColumn(col_name, df[col_name].cast(LongType()))
                                elif str(dl_dtype) == 'ShortType':
                                    df = df.withColumn(col_name, df[col_name].cast(ShortType()))
                                elif str(dl_dtype) == 'FloatType':
                                    df = df.withColumn(col_name, df[col_name].cast(FloatType()))
                                elif str(dl_dtype) == 'ByteType':
                                    df = df.withColumn(col_name, df[col_name].cast(ByteType()))
                                elif str(dl_dtype) == 'DecimalType(10,0)':
                                    df = df.withColumn(col_name, df[col_name].cast(DecimalType(int(precision), int(scale))))
                                else:
                                    df = df.withColumn(col_name, substring(df[col_name].cast(StringType()), 1, int(precision)))
                            elif col_name == 'REC_CREN_DTTM':
                                df = df.withColumn(col_name, lit(current_timestamp()))
                            elif col_name == 'REC_LAST_UPD_DTTM':
                                df = df.withColumn(col_name, lit(current_timestamp()))
                            elif col_name == 'REC_CREN_USR_ID':
                                df = df.withColumn(col_name, lit(user))
                            elif col_name == 'REC_LAST_UPD_USR_ID':
                                df = df.withColumn(col_name, lit(user))
                            elif col_name == 'REC_CRE_BCH_ID':
                                df = df.withColumn(col_name, lit(prcs_excn_log_id).cast(LongType()))
                            elif str(dl_dtype) == 'TimestampType':
                                df = df.withColumn(col_name, lit(None).cast(TimestampType()))
                            elif str(dl_dtype) == 'DateType':
                                df = df.withColumn(col_name, lit(None).cast(DateType()))
                            elif str(dl_dtype) == 'IntegerType':
                                df = df.withColumn(col_name, lit(None).cast(IntegerType()))
                            elif str(dl_dtype) == 'LongType':
                                df = df.withColumn(col_name, lit(None).cast(LongType()))
                            elif str(dl_dtype) == 'ShortType':
                                df = df.withColumn(col_name, lit(None).cast(ShortType()))
                            elif str(dl_dtype) == 'FloatType':
                                df = df.withColumn(col_name, lit(None).cast(FloatType()))
                            elif str(dl_dtype) == 'ByteType':
                                df = df.withColumn(col_name, lit(None).cast(ByteType()))
                            elif str(dl_dtype) == 'DecimalType(10,0)':
                                    df = df.withColumn(col_name, lit(None).cast(DecimalType(int(precision), int(scale))))
                            else:
                                df = df.withColumn(col_name, lit(None).cast(StringType()))
                        
                        df_n = df.select(*col_names)
                        # df_n.printSchema()
                        
                        if partition_by != "":
                            df_n = df_n.withColumn(partition_by, lit(prcs_excn_log_id).cast(LongType()))
                            df_n.write.format("parquet").option("partitionOverwriteMode", "dynamic").mode("overwrite").partitionBy(partition_by).save(target_loc_final)
                        else:
                            df_n.write.format("parquet").option("partitionOverwriteMode", "dynamic").mode("overwrite").save(target_loc_final)
                            
                        self.logger.info("Done!")
                        self.logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                    except Exception as err:
                        self.logger.error(err)
                        Run_status = 1                 
            
            if Run_status == 0:
                return True
            else:        
                return False
        except Exception as err:
            self.logger.error(err)
            raise err
            return False

    def replace(self, argument):
        if re.search("^TIMESTAMP", argument) != None:
            val = TimestampType()
        elif re.search("^CHARACTER", argument) != None:
            val = StringType()
        elif re.search("^VARCHAR", argument) != None:
            val = StringType()
        elif re.search("^CHAR", argument) != None:
            val = StringType()
        elif re.search("^BIGINT", argument) != None:
            val = LongType()
        elif re.search("^SMALLINT", argument) != None:
            val = ShortType()
        elif re.search("^DATE", argument) != None:
            val = DateType()
        elif re.search("^INTEGER", argument) != None:
            val = IntegerType()
        elif re.search("^INT", argument) != None:
            val = IntegerType()
        elif re.search("^NUMERIC", argument) != None:
            val = DecimalType()
        elif re.search("^DECIMAL", argument) != None:
            val = DecimalType()
        elif re.search("^BYTEINT", argument) != None:
            val = ByteType()
        else:
            val = argument
        return val

    
p_conversion = parquet_conversion()

