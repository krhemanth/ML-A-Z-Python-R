

import boto3
import os
from logger  import mylogger


class pam_utils(object):
    logger = mylogger.getLogger("pam_utils")
    
    def get_pam_details(self, dataBase):
        try:
            PamBucketName = os.getenv('pam_bucket_name')
            PamObjectName = os.getenv('%s_pam_object_name' % dataBase)
            s3 = boto3.resource('s3')
            s3obj = s3.Object(PamBucketName, PamObjectName).get()['Body'].read().decode('utf-8').split("\n")
            pamdict = {}
            for eachline in s3obj:
                if (eachline):
                    eachelement = eachline.split("=", 1)
                    key = eachelement[0].strip()
                    value = eachelement[1].strip()
                    pamdict[key] = value
            
            return(pamdict)
        except Exception as e:
            raise e


pam = pam_utils()
