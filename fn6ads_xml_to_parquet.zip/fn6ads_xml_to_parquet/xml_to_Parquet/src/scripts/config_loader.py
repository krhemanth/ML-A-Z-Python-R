# information and trade secrets of  Fannie Mae. Use, disclosure, or reproduction is    
# prohibited without the prior written consent of  Fannie Mae.
# 
# Created on Fri Jun 14 13:44:07 2020
# 
# @author: gaupbn, g9usqv
# 
# Loads env configurations
# =============================================================================

import dotenv
from dotenv import load_dotenv
import os


class Config:
          
    def __init__(self):
        try:
            
            path = os.getcwd()
            relative_path = os.path.relpath(path, 'src')
            config_path = relative_path + '/config/config.env'
            
            print ('Config path :' + config_path)

            '''load env variables'''
            # found_dotenv = dotenv.find_dotenv('../config/config.env')
            found_dotenv = dotenv.find_dotenv(config_path)
            print('Loading environment config.......', end='')
            load_dotenv(found_dotenv)
            print(' Done')
                
        except Exception as e:
            print('Error happened during loading environment configuration :')
            print('Unhandled exception :' + format(e))


config = Config()
